#include "command_base.h"

using namespace std;

// ---------------------------------------------------------------------------
// Constructor 
// Default constructor for command_base class
command_base::command_base()
{
}

// ---------------------------------------------------------------------------
// next
// returns next command to be processed
CommandData* command_base::next()
{
	CommandData* temp = NULL;
	return temp;
};
