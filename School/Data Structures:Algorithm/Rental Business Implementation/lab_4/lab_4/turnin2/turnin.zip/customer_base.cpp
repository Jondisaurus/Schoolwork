
#include "customer_base.h"

// ---------------------------------------------------------------------------
// Constructor 
// Default constructor for MediaStore class
customer_base::customer_base()
{
}
