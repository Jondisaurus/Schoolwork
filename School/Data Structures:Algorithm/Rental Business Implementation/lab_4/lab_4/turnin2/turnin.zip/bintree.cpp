#include "bintree.h"

//++===== CPP Cope Behind for the BinTree class contained in bintree.h =======++











